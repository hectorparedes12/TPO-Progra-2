package org.example.implementation.normal;

import org.example.definition.Queue;

public class QueueOfStacks implements Queue {

    private StaticStack[] pilas;
    private int frente;
    private int finalCola;

    public QueueOfStacks(int capacidad) {
        this.pilas = new StaticStack[capacidad];
        for (int i = 0; i < capacidad; i++) {
            this.pilas[i] = new StaticStack();
        }
        this.frente = 0;
        this.finalCola = -1;
    }

    @Override
    public void add(int elemento) {
        if (finalCola == pilas.length - 1) {
            throw new RuntimeException("Cola llena");
        }
        pilas[++finalCola].add(elemento);
    }

    @Override
    public void remove() {
        if (isEmpty()) {
            throw new RuntimeException("Cola vacía");
        }
        pilas[frente].remove();
        if (pilas[frente].isEmpty()) {
            frente++;
        }
    }

    @Override
    public boolean isEmpty() {
        return frente > finalCola;
    }

    @Override
    public int getFirst() {
        if (isEmpty()) {
            throw new RuntimeException("Cola vacía");
        }
        return pilas[frente].getTop();
    }

    public void imprimirMatriz() {
        for (int i = frente; i <= finalCola; i++) {
            System.out.print("Fila " + (i - frente + 1) + ": ");
            imprimirPila(pilas[i]);
        }
    }

    private void imprimirPila(StaticStack pila) {
        StaticStack tempStack = new StaticStack();
        while (!pila.isEmpty()) {
            int elemento = pila.getTop();
            System.out.print(elemento + " ");
            tempStack.add(elemento);
            pila.remove();
        }
        while (!tempStack.isEmpty()) {
            pila.add(tempStack.getTop());
            tempStack.remove();
        }
        System.out.println();
    }
}
