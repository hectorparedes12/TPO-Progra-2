package org.example.implementation.dynamic;

import org.example.definition.Stack;
import org.example.implementation.dynamic.nodes.Node;

import java.util.Objects;

public class DynamicStackLimitada implements Stack {

    private Node first;
    private int size;
    private final int maxCapacity;

    public DynamicStackLimitada(int maxCapacity) {
        this.first = null;
        this.size = 0;
        this.maxCapacity = maxCapacity;
    }

    @Override
    public void add(int a) {
        if (size == maxCapacity) {
            throw new RuntimeException("Pila llena, no se puede añadir más elementos");
        }
        Node newNode = new Node(a, this.first);
        this.first = newNode;
        size++;
    }

    @Override
    public void remove() {
        if (isEmpty()) {
            throw new RuntimeException("No se puede desapilar una pila vacía");
        }
        this.first = this.first.getNext();
        size--;
    }

    @Override
    public int getTop() {
        if (isEmpty()) {
            throw new RuntimeException("No se puede obtener el tope de una pila vacía");
        }
        return this.first.getValue();
    }

    @Override
    public boolean isEmpty() {
        return Objects.isNull(this.first);
    }
}
