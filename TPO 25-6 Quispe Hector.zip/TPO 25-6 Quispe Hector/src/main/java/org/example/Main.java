package org.example;


import org.example.implementation.normal.QueueOfStacks;
import org.example.implementation.normal.StaticSet;
import org.example.implementation.normal.StaticStack;

public class Main {
    public static void main(String[] args) {

        //Ejercicio 2.1
        StaticStack stack = new StaticStack();
        stack.add(1);
        stack.add(2);
        stack.add(3);
        System.out.println("Pila original:");
        printStack(stack);
        invertirStack(stack);
        System.out.println("Pila invertida:");
        printStack(stack);

        //Ejercicio 2.2
        StaticSet originalSet = new StaticSet();
        originalSet.add(1);
        originalSet.add(2);
        originalSet.add(3);
        System.out.println("Conjunto original:");
        printSet(originalSet);

        StaticSet copiaSet = copiarSet(originalSet);
        System.out.println("Conjunto copiado:");
        printSet(copiaSet);

        //Ejercicio 5.1

        StaticStack originalStack = new StaticStack();
        originalStack.add(3);
        originalStack.add(7);
        originalStack.add(8);
        originalStack.add(5);
        originalStack.add(1);
        originalStack.add(5);

        System.out.println("Pila original");
        printStack(originalStack);

        StaticStack sortedUniqueStack = generateSortedUniqueStack(originalStack);
        System.out.println("Pila ordenada sin repetidos");
        printStack(sortedUniqueStack);


    }
    public static void invertirStack(StaticStack stack){
        StaticStack tempStack = new StaticStack();
        StaticStack invertedStack = new StaticStack();
        while (!stack.isEmpty()) {
            tempStack.add(stack.getTop());
            stack.remove();
        }
        while (!tempStack.isEmpty()) {
            invertedStack.add(tempStack.getTop());
            tempStack.remove();
        }
        while (!invertedStack.isEmpty()) {
            stack.add(invertedStack.getTop());
            invertedStack.remove();
        }
    }

    public static void printStack(StaticStack stack) {
        StaticStack tempStack = new StaticStack();
        while (!stack.isEmpty()) {
            int top = stack.getTop();
            System.out.println(top);
            tempStack.add(top);
            stack.remove();
        }
        while (!tempStack.isEmpty()) {
            stack.add(tempStack.getTop());
            tempStack.remove();
        }
    }

    public static StaticSet copiarSet(StaticSet originalSet){
        StaticSet copiaSet = new StaticSet();
        StaticSet tempSet = new StaticSet();
        while (!originalSet.isEmpty()) {
            int elemento = originalSet.choose();
            copiaSet.add(elemento);
            tempSet.add(elemento);
            originalSet.remove(elemento);
        }

        while (!tempSet.isEmpty()) {
            int elemento = tempSet.choose();
            originalSet.add(elemento);
            tempSet.remove(elemento);
        }
        return copiaSet;
        }

    public static void printSet(StaticSet set) {
        StaticSet tempSet = new StaticSet();
        while (!set.isEmpty()) {
            int elemento = set.choose();
            System.out.println(elemento);
            tempSet.add(elemento);
            set.remove(elemento);
        }
        while (!tempSet.isEmpty()) {
            int elemento = tempSet.choose();
            set.add(elemento);
            tempSet.remove(elemento);
        }

    }

    public static StaticStack generateSortedUniqueStack(StaticStack stack) {
        StaticStack uniqueStack = new StaticStack();
        StaticStack sortedStack = new StaticStack();

        while (!stack.isEmpty()) {
            int element = stack.getTop();
            stack.remove();
            if (!contains(uniqueStack, element)) {
                uniqueStack.add(element);
            }
        }
        while (!uniqueStack.isEmpty()) {
            int temp = uniqueStack.getTop();
            uniqueStack.remove();
            sortedInsert(sortedStack, temp);
        }

        return sortedStack;
    }

    public static void sortedInsert(StaticStack stack, int element) {
        StaticStack tempStack = new StaticStack();

        while (!stack.isEmpty() && stack.getTop() > element) {
            tempStack.add(stack.getTop());
            stack.remove();
        }

        stack.add(element);

        while (!tempStack.isEmpty()) {
            stack.add(tempStack.getTop());
            tempStack.remove();
        }
    }

    public static boolean contains(StaticStack stack, int element) {
        StaticStack tempStack = new StaticStack();
        boolean found = false;
        while (!stack.isEmpty()) {
            int top = stack.getTop();
            if (top == element) {
                found = true;
            }
            tempStack.add(top);
            stack.remove();
        }
        while (!tempStack.isEmpty()) {
            stack.add(tempStack.getTop());
            tempStack.remove();
        }
        return found;
    }

}